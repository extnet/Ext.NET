namespace cleanProject.Models
{
    public class ExtNetModel
    {
        public string Title { get; set; }
        public string TextAreaEmptyText { get; set; }
    }
}