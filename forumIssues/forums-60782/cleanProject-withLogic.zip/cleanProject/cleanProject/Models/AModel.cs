﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace cleanProject.Models
{
    public class AModel
    {
        #region Variables
        private bool mbUseSoap = false;
        #endregion Variables

        #region Constructors
        public AModel()
        {
        }
        #endregion Constructors
    }
}