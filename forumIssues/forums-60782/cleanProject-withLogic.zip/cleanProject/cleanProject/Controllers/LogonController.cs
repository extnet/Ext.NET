﻿using Ext.Net;
using Ext.Net.MVC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace cleanProject.Controllers
{
    public class LogonController : Controller
    {
        #region Constructors

        public LogonController()
        {
        }

        #endregion Constructors


        public System.Web.Mvc.ActionResult Index(Models.ClearviewModel model)
        {
            bool bCloseAndSendToLogin = false;

            return this.View(model);
        }

        [System.Web.Mvc.HttpPost]
        public ActionResult Index
                (Models.ClearviewModel clearviewModel
                    , string redirectAction = "Index"
                        , string redirectController = "Clearview")
        {

            JFunction oHideMaskJFunction = new JFunction("HideLogonMask");

            if (ModelState.IsValid)
            {
                return this.TryLogon(clearviewModel, oHideMaskJFunction);
            }
            else
            {
                X.Msg.Alert("Incomplete Logon", "Please fill out all fields.", oHideMaskJFunction).Show();

                return this.Direct();
            }
        }

        private ActionResult TryLogon(Models.ClearviewModel clearviewModel, JFunction hideMaskJFunction)
        {
            return this.RedirectToAction
                    ("Index", "Clearview", new
                    {
                        token = "token",
                        useSoap = false
                    });

        }
    }
}