﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace cleanProject.Controllers
{
    public class ClearviewController : Controller
    {
		#region Constructors
		public ClearviewController (  )
		{
		}
		#endregion Constructors

		#region Homepage Controllers
		public System.Web.Mvc.ActionResult Index ( string token , string useSoap = "false" )
		{
			return this.View (  );
		}
		#endregion Homepage Controllers
    }
}