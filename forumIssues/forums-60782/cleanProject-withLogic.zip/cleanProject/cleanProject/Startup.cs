﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(cleanProject.Startup))]
namespace cleanProject
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
