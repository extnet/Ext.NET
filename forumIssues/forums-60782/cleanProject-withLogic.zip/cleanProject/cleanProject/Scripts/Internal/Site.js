﻿

function parseBool( value )
{

    var isBool = false;
    if ( value !== undefined && value != null && value != false )
    {
        isBool = value === true || parseInt( value ) === 1 || value.toLowerCase() === "true" ? true : false;
    }
    return isBool;
}
function ReplaceWhiteSpace( value )
{
    sReturnValue = value.replace( /\s/g, "" );

    return sReturnValue;
}

if ( !String.prototype.trim )
{
    String.prototype.trim = function () { return this.replace( /^\s+|\s+$/g, '' ); };
}

if ( !String.prototype.endsWith )
{
    String.prototype.endsWith = function ( searchString, position )
    {
        var subjectString = this.toString();
        if ( typeof position !== 'number' || !isFinite( position ) || Math.floor( position ) !== position || position > subjectString.length )
        {
            position = subjectString.length;
        }
        position -= searchString.length;
        var lastIndex = subjectString.indexOf( searchString, position );
        return lastIndex !== -1 && lastIndex === position;
    };
}

if ( !String.prototype.startsWith )
{
    String.prototype.startsWith = function ( searchString, position )
    {
        position = position || 0;
        return this.substr( position, searchString.length ) === searchString;
    };
}

String.prototype.ToSelector = function () { return this.replace( /\./g, "\\\." ); };


function IsANumber( value )
{
    var bReturn = ( typeof value !== 'undefined' && isNaN( value ) == false && value.toString().trim() != '' ) ? true : false;
    return bReturn;
}

function IsNullOrWhiteSpace( str )
{
    return str === null || str.match( /^\s*$/ ) !== null;
}

function HandleMenuSearchSelection( searchBox )
{


    if ( searchBox.lastSelection && searchBox.lastSelection.length > 0 )
    {
        if ( searchBox.lastSelection[0].data.DefaultText.indexOf( "Logoff" ) > -1 )
        {
            searchBox.setValue( "" );

            Ext.ComponentQuery.query( '#btnLogoff' )[0].fireEvent( 'click' );
        }
        else
        {


            var OpenComannd = searchBox.lastSelection[0].data.FullLaunchContainerUrl;

            var OpenParameterString = OpenComannd.replace( "window.open('", "" ).replace( "');", "" );

            var OpenParameters = OpenParameterString.split( "','" );

            searchBox.setValue( "" );

            window.open( OpenParameters[0], OpenParameters[1], OpenParameters[2] )
        }

        
    }

    return ( false );
}


function HandleCloseOnLogoff( extWindow )
{
    if ( window.opener )
    {
        window.opener.location.href = sRoot + "Logon";
        window.close;
    }
    else
    {
        location.href = sRoot + "Logon";
    }
}

function HandleOtherErrorWindows( extWindow )
{
    var oAllExtWindows = Ext.ComponentQuery.query( "#ErrorWindow" );

    for ( var i = 0; i < oAllExtWindows.length ; i++ )
    {
        if ( extWindow != oAllExtWindows[i] )
        {
            oAllExtWindows[i].suspendEvents();
            oAllExtWindows[i].close();
            oAllExtWindows[i].resumeEvents();
        }
    }
}

function ComponentLoadFailure( loader, response, loaderType )
{
    /*we only want to run this when it's not an invalid token error*/
    if ( response.responseText.indexOf( "<script" ) == -1 )
    {
        var sToken
            = ( App.Token )
            ? App.Token.getValue()
            : "";

        Ext.net.DirectMethod.request( {
            url: sRoot + "Error/ComponentLoaderError",
            cleanRequest: true,
            params: {
                loadedComponent: loaderType
                , containerId: loader.params.containerId
                , HTMLErrorMessage: response.responseText
                , token: sToken

            },
            success: function ( result )
            {
                ErrorWindow( result.ErrorMessage.DetailedErrorMessage, result.ErrorMessage.FriendlyErrorMessage )
            }

        } );
    }
}

function ErrorWindow( detailedErrorMessage, friendlyErrorMessage )
{
    var sToken
            = ( App.Token )
            ? App.Token.getValue()
            : "";

    Ext.net.DirectMethod.request( {
        url: sRoot + "Error/ErrorWindow",
        json: true,
        cleanRequest: true,
        params: {
            DetailedErrorMessage: detailedErrorMessage
            , FriendlyErrorMessage: friendlyErrorMessage
            , token: sToken
        }
    } );
}

function SelectText( elementId )
{
    var oElement = document.getElementById( elementId )
        , oRange, oSelection
    ;
    if ( document.body.createTextRange )
    {
        oRange = document.body.createTextRange();
        oRange.moveToElementText( oElement );
        oRange.select();
    } else if ( window.getSelection )
    {
        oSelection = window.getSelection();
        oRange = document.createRange();
        oRange.selectNodeContents( oElement );
        oSelection.removeAllRanges();
        oSelection.addRange( oRange );
    }

    try
    {
        document.execCommand( 'copy' );
    }
    catch ( ex )
    {
        alert( 'copying is not allowed in this browser' );
    }
}

function CopyErrorToClipboard( reference )
{

    var oTopLevelObject = reference.up( 'window' ) ? reference.up( 'window' ) : reference.up( 'viewport' );

    var oToggleButton = oTopLevelObject.down( '#btnErrorToggleButton' ),
        oPanel = oTopLevelObject.down( '#ErrorPanel' ),
        oFriendlyErrorMessage = oPanel.down( '#FriendlyErrorMessage' ),
        oDetailedErrorMessage = oPanel.down( '#DetailedErrorMessage' )

    var bResetSummary = false;

    if ( oFriendlyErrorMessage.isVisible() )
    {
        oFriendlyErrorMessage.hide();
        oDetailedErrorMessage.show();
        bResetSummary = true;
    }

    var sElementId = oDetailedErrorMessage.getEl().dom.id + '-innerCt';

    SelectText( sElementId );

    if ( bResetSummary )
    {
        oFriendlyErrorMessage.show();
        oDetailedErrorMessage.hide();
    }
}

function ResizeErrorWindow( window )
{
    var iHeight = window.getHeight();

    window.down( "#ErrorPanel" ).setHeight( iHeight - 60 );
    
}

function MailToFromButton( mailSubject, mailBody )
{
                                                                      ResizeErrorWindow
    window.location.href = "mailto:?subject=" + mailSubject + "&body=" + mailBody.replace( /\%3Cbr\%2F\%3E/g, "" );
}


function ArrowNext( e, radio )
{
    var oGroupItems = radio.up().items.items

    var iNextFocus = 0;

    switch ( e.keyCode )
    {
        case 37:
        case 38:
            iNextFocus = -1;
            break;

        case 39:
        case 40:
            iNextFocus = 1;
            break;
    }


    if ( iNextFocus != 0 )
    {
        var iFocusIndex;

        for ( var i = 0 ; i < oGroupItems.length ; i++ )
        {
            if ( oGroupItems[i] == radio )
            {

                if ( i + iNextFocus == oGroupItems.length )
                {
                    iFocusIndex = 0;
                }
                else if ( i + iNextFocus == -1 )
                {
                    iFocusIndex = oGroupItems.length - 1
                }
                else
                {
                    iFocusIndex = i + iNextFocus;
                }

            }


        }

        oGroupItems[iFocusIndex].focus();
        oGroupItems[iFocusIndex].setValue( true );

    }
}

function PreventBackspace( reference, e )
{
    if ( e.keyCode == 8 && reference.xtype != "textfield" && reference.xtype != "combobox" )
    {
        e.preventDefault();
    }
}

function findComponentByElement( node )
{
    var topmost = document.body,
        target = node,
        cmp;

    while ( target && target.nodeType === 1 && target !== topmost )
    {
        cmp = Ext.getCmp( target.id );

        if ( cmp )
        {
            return cmp;
        }

        target = target.parentNode;
    }

    return null;
}

function StoreToJson( store, control )
{
    control.setValue( Ext.encode( Ext.pluck( store.data.items, 'data' ) ) );
}

function Log( object )
{
    if ( typeof console !== "undefined" || typeof console.log !== "undefined" )
    {
        console.log( object );
    }
}
