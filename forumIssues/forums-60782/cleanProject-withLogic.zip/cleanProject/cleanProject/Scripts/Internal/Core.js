﻿/// <reference path="External/Ext/ext-all-debug-v3.js" />
/// <reference path="External/Ext/extnet_all-v3.js" />
/// <reference path="../External/JQuery/jquery-1.11.3.min.js" />

var Core = Core || {};

( function ()
{
	this.Meta = this.Meta || {};

	( function ()
	{
		this.IsNumeric = function ( value )
		{
			var bReturn
				= ( typeof value !== 'undefined'
						&& isNaN( value ) == false
							&& value.toString().Trim() != '' )
								? true
									: false;

			return bReturn;
		}
	}
	).apply( this.Meta || {} );

	this.Ext = this.Ext || {};

	( function ()
	{
		this.ShowMask = function ( theObject, message )
		{
			theObject.mask( message );
		}

		this.HideMask = function ( theObject )
		{
			theObject.unmask();
		}

		this.TopLevelContainerId = function ( reference )
		{
			sContainerId = "";
			if ( reference.up( 'window' ) )
			{
				sContainerId = reference.up( 'window' ).container.id;
			}
			else
			{
				sContainerId = reference.up( 'viewport' ).down( 'panel' ).container.id;
			}

			return sContainerId;

		};

		this.TopLevelContainer = function ( reference )
		{
			sContainer = null;
			if ( reference.up( 'window' ) )
			{
				sContainer = reference.up( 'window' );
			}
			else
			{
				sContainer = reference.up( 'viewport' ).down( 'panel' );
			}

			return sContainer;

		};
	}

	).apply( this.Ext || {} );

	this.ErrorWindow = function ( detailedErrorMessage, friendlyErrorMessage )
	{
		var sToken
				= ( App.Token )
				? App.Token.getValue()
				: "";

		Ext.net.DirectMethod.request( {
			url: sRoot + "Error/ErrorWindow",
			json: true,
			cleanRequest: true,
			params: {
				DetailedErrorMessage: detailedErrorMessage
				, FriendlyErrorMessage: friendlyErrorMessage
				, token: sToken
			}
		} );
	}

} ).apply( Core || {} );

// prototypes

String.prototype.IsNullOrBlank = function ()
{
	return this === null || this.match( /^\s*$/ ) !== null;
};

String.prototype.Trim = function ()
{
	return this.replace( /^\s+|\s+$/g, '' );
};

String.prototype.EndsWith = function ( searchString, position )
{
	var sSubjectString = this.toString();

	if ( typeof position !== 'number'
			|| !isFinite( position )
				|| Math.floor( position ) !== position
					|| position > sSubjectString.length )
	{
		position = sSubjectString.length;
	}

	position -= searchString.length;

	var iLastIndex
		= sSubjectString.indexOf
			( searchString, position );

	return iLastIndex !== -1 && lastIndex === position;
};

String.prototype.StartsWith = function ( searchString, position )
{
	position = position || 0;

	return this.substr( position, searchString.length ) === searchString;
};


