﻿//$( document ).unbind( 'keydown' ).bind( 'keydown', function ( event )
//{
//    var doPrevent = false;
//    if ( event.keyCode === 8 )
//    {
//        alert( 'backspace' );
//        var d = event.srcElement || event.target;
//        if ( ( d.tagName.toUpperCase() === 'INPUT' &&
//             (
//                 d.type.toUpperCase() === 'TEXT' ||
//                 d.type.toUpperCase() === 'PASSWORD' ||
//                 d.type.toUpperCase() === 'FILE' ||
//                 d.type.toUpperCase() === 'EMAIL' ||
//                 d.type.toUpperCase() === 'SEARCH' ||
//                 d.type.toUpperCase() === 'DATE' )
//             ) ||
//             d.tagName.toUpperCase() === 'TEXTAREA' )
//        {
//            alert( d.type );
//            doPrevent = d.readOnly || d.disabled;
//        }
//        else
//        {
//            doPrevent = true;
//            alert( 'prevented' );
//        }
//    }

//    if ( doPrevent )
//    {
//        event.preventDefault();
//    }
//} );

function ToggleObjectById( theObjectID )
{
    $( "#" + theObjectID ).toggle();
    
}

function CollapseContent( button )
{
    var panel = Ext.getCmp( 'MainContentContainer' );
    var isCollapsed = panel.getCollapsed();

    if ( isCollapsed != false ){ /*note: getCollapsed returns either false or the collapse direction*/
        isCollapsed = true; 
    }

    if ( isCollapsed )
    {
        button.setText( "Hide Content" );
    }
    else
    {
        button.setText( "Show Content" );
    }
    
    panel.toggleCollapse()

}

jQuery.fn.alignToCenter = function ()
{
    this.css( "position", "absolute" );
    this.css( "top", Math.max( 0, ( ( $( window ).height() - $( this ).outerHeight() ) / 2 ) +
                                                $( window ).scrollTop() ) + "px" );
    this.css( "left", Math.max( 0, ( ( $( window ).width() - $( this ).outerWidth() ) / 2 ) +
                                                $( window ).scrollLeft() ) + "px" );
    return this;
}

//var TopLevelContainerId = function ( reference )
//{
//    sContainerId = "";
//    if ( reference.up( 'window' ) )
//    {
//        sContainerId = reference.up( 'window' ).container.id;
//    }
//    else
//    {
//        sContainerId = reference.up( 'viewport' ).down( 'panel' ).container.id;
//    }

//    return sContainerId;

//};

//var TopLevelContainer = function ( reference )
//{
//    sContainer = null;
//    if ( reference.up( 'window' ) )
//    {
//        sContainer = reference.up( 'window' );
//    }
//    else
//    {
//        sContainer = reference.up( 'viewport' ).down( 'panel' );
//    }

//    return sContainer;

//};

//var ShowMask = function ( obj , message )
//{
//	var oMask = new Ext.LoadMask( { msg: message , target: obj } );

//	oMask.show();
//};

//var HideMask = function ( obj )
//{
//	var oMask = new Ext.LoadMask( { msg: "", target: obj } );

//	oMask.hide();
//};

function ToggleErrorDetails( reference )
{

    var oTopLevelObject = reference.up( 'window' ) ? reference.up( 'window' ) : reference.up( 'viewport' );


    var oPanel = oTopLevelObject.down( '#ErrorPanel' ),
        oFriendlyErrorMessage = oPanel.down( '#FriendlyErrorMessage' ),
        oDetailedErrorMessage = oPanel.down( '#DetailedErrorMessage' )

    if ( oFriendlyErrorMessage.isVisible() )
    {
        oFriendlyErrorMessage.hide();
        oDetailedErrorMessage.show();

        reference.setText( "Summary" );
    }
    else
    {
        oFriendlyErrorMessage.show();
        oDetailedErrorMessage.hide();

        reference.setText( "Details" );
    };
}

function ScreenReset( btn )
{
    
    if ( btn == 'yes' )
    {

        var oLayout = Ext.ComponentQuery.query( '#ClearviewLayout' )[0];
        var oScreen = Ext.getBody().getViewSize();

        var oHeaderRegion = oLayout.down( '#HeaderRegion' );
        var oMenuRegion = oLayout.down( '#MenuRegion' );
        var oCenterRegion = oLayout.down( '#CenterRegion' );
        var oFavouritesRegion = oLayout.down( '#FavouritesRegion' );

        var oContentPanel = oLayout.down( '#ContentPanel' );
        var oGroupDisplayPanel = oLayout.down( '#GroupDisplayPanel' );

        var iContentPanelHeight = 0;

        oMenuRegion.expand();
        oFavouritesRegion.expand();
        oGroupDisplayPanel.expand();

        oMenuRegion.setWidth( 200 );
        oFavouritesRegion.setWidth( 200 );

        if ( oContentPanel )
        {

            oContentPanel.setHeight( 150 );

            setTimeout( function ()
            {

                oContentPanel.expand();

                setTimeout( function ()
                {
                    oContentPanel.setHeight( 150 ); /*set this twice - expanding causes issues otherwise*/

                    iContentPanelHeight = oContentPanel.getHeight();

                    oGroupDisplayPanel.setHeight( oCenterRegion.getHeight() - iContentPanelHeight );



                }, 500 );

            }, 1000 );
        }
        else
        {
            oGroupDisplayPanel.setHeight( oCenterRegion.getHeight() );

        }
    }
}

function ScreenMaximize()
{

    var oLayout = Ext.ComponentQuery.query( '#ClearviewLayout' )[0];
    var oScreen = Ext.getBody().getViewSize();

    var oHeaderRegion = oLayout.down( '#HeaderRegion' );
    var oMenuRegion = oLayout.down( '#MenuRegion' );
    var oCenterRegion = oLayout.down( '#CenterRegion' );
    var oFavouritesRegion = oLayout.down( '#FavouritesRegion' );

    var oContentPanel = oLayout.down( '#ContentPanel' );
    var oGroupDisplayPanel = oLayout.down( '#GroupDisplayPanel' );

    var iContentPanelHeight = 0;

    oMenuRegion.expand();
    oFavouritesRegion.collapse();
    oGroupDisplayPanel.expand();

    if ( oContentPanel )
    {
        oContentPanel.collapse();

        setTimeout( function ()
            {
 
                iContentPanelHeight = oContentPanel.getHeight();
                oGroupDisplayPanel.setHeight( oCenterRegion.getHeight() - iContentPanelHeight );
                
            }, 500 );
    }
    else
    {
        oGroupDisplayPanel.setHeight( oCenterRegion.getHeight() );
    }


}
           
function ResizeGroupDisplay( contentPanel , method )
{
    var oLayout = contentPanel.up( '#ClearviewLayout' );
    var oCenterRegion = oLayout.down( '#CenterRegion' );
    var oGroupDisplayPanel = oLayout.down( '#GroupDisplayPanel' );

    if ( oGroupDisplayPanel && oGroupDisplayPanel.collapsed == false )
    {        
        oGroupDisplayPanel.setHeight( oCenterRegion.getHeight() - contentPanel.getHeight() );
    }
}

function MaximizeGroupDisplaySpace( loader )
{
    
    var oTab = loader.target;
    var oPanel = oTab.up( 'panel' )
    var oGroupDisplay = oTab.up( 'panel' )
    var oRegion = oGroupDisplay.up( 'panel' )

    var oContentPanel = oRegion.down( '#ContentPanel' );

    var iContentPanelHeight = 0

    if ( oContentPanel != null )
    {
        iContentPanelHeight = oContentPanel.getHeight();
    };

    if ( oGroupDisplay.getHeight() != ( oRegion.getHeight() - iContentPanelHeight ) )
    {
        oGroupDisplay.setHeight( ( oRegion.getHeight() - iContentPanelHeight ) );
    }
   
}

function ContentPanelWidth( section )
{
    var oLayout = section.up( '#ClearviewLayout' );

    var oCenterRegion = oLayout.down( '#CenterRegion' );

    var oContentPanel = oLayout.down( '#ContentPanel' );
    
    oContentPanel.setWidth( oCenterRegion.getWidth()-2 );
    
}