﻿/// <reference path="External/JQuery/jquery-1.11.3.min.js" />
/// <reference path="External/Ext/ext-all-debug-v3.js" />
/// <reference path="External/Ext/extnet_all-v3.js" />
/// <reference path="Core.js" />

var window_focus = true;

$( window ).focus( function ()
{
	window_focus = true;
} )
	.blur( function ()
	{
		window_focus = false;
	} );

/*** Renderers & Command Scripts ***/

var Core = Core || {};

( function ()
{
	this.Browser = this.Browser || {};

	( function ()
	{
		var moTemplate = '<span>{0}</span>';

		var moBoxTemplate = '<div style="background-color:{0}; width: 20px;">&nbsp;</div>';

		var moFixedTemplate = '<span style="color:{0};">{1}</span>';

		this.ColorFieldRenderer = function ( value )
		{
			var sHexColor = "000000" + value.toString( 16 );

			sHexColor = sHexColor.substr( sHexColor.length - 6 );

			return Ext.String.format( this.moBoxTemplate, ( value > -1 ) ? "#" + sHexColor.toString() : "", sHexColor.toString() );
		};

		this.FixedFilter = function ( column )
		{
			if ( column.record.get( 'FixedFlag' ) )
			{
				column.config[0].disabled = true;
			}
		};

		this.EditGridCommandPrepare = function ( grid, command, record, row )
		{
			if ( command.command == 'Delete' && record.data.FixedFlag )
			{
				command.hidden = true;

				command.hideMode = 'display';
			}
		};

		this.RenderGridBool = function ( value, meta, record )
		{
			var sCheckbox = Ext.String.format( '<img src="{0}resources/images/GridCheckboxEmpty.png" border="0" />', sRoot );

			if ( parseBool( value ) )
			{
				sCheckbox = Ext.String.format( '<img src="{0}resources/images/GridCheckboxChecked.png" border="0" />', sRoot );
			}

			return sCheckbox;
		};

		this.LineBreaks = function ( value, meta, record )
		{
			var sValue = Ext.util.Format.htmlEncode( value );

			sValue = Ext.util.Format.nl2br( sValue );

			return sValue;
		};

		/*** End Renderers & Command Scripts ***/

		/*** Configuration Scripts ***/

		this.ChangeConfiguration = function ( combobox )
		{
			combobox.up( '#TopLevelBrowser' ).down( '#tabFilterCriteria' ).getStore().removeAll();

			combobox.up( '#TopLevelBrowser' ).down( '#tabSortCriteria' ).getStore().removeAll();

			var oDeleteButton = combobox.up( '#TopLevelBrowser' ).down( '#btnDelete' );

			this.CheckDeleteButtonDisabled( combobox, oDeleteButton );

			combobox.up( '#TopLevelBrowser' ).down( '#tabFilterSortPanel' ).setActiveTab( 0 );

			this.StoresToJson( combobox );

			this.ClearJsonStores( combobox );
		};

		this.SaveConfigurationButton = function ( button, browserGuid )
		{
			var oReplaceRegex = /\[*\*+\]*/g;

			var oConfig = button.up( '#TopLevelBrowser' ).down( '#ConfigurationIds' );

			var sThisRecordText = oConfig.getRawValue().replace( oReplaceRegex, "" ).Trim();

			var oSelectedRecord = sThisRecordText.Trim() == ""
								  ? oConfig.getStore().getAt( 0 )
								  : oConfig.getStore().findRecord( 'Ids', oConfig.getValue() );

			var sUserId = oSelectedRecord.get( 'UserId' ).toLowerCase().Trim();

			if ( sUserId != "admin" && sUserId != "" )
			{
				var sConfigurationName = oSelectedRecord.get( 'ConfigurationName' ).replace( oReplaceRegex, "" );

				var sConfigurationDescription = oSelectedRecord.get( 'Description' ).replace( oReplaceRegex, "" );

				this.SubmitDirectConfigSave( button, sConfigurationName, sConfigurationDescription );
			} else
			{
				Ext.ComponentQuery.query( '#SaveConfigurationWindow' + browserGuid )[0].show();
			}

			button.blur();
		};

		this.SaveConfigWindow = function ( reference, browserGuid )
		{
			var oThisBrowser = FindBrowserByGuid( browserGuid );

			var oReplaceRegex = /\[*\*+\]*/g;

			var sThisRecordText = oThisBrowser.down( '#ConfigurationIds' ).getRawValue().replace( oReplaceRegex, "" );

			var oSelectedRecord = oThisBrowser.down( '#ConfigurationIds' ).getStore().findRecord( 'Description', sThisRecordText );

			var sConfigurationName = "";

			if ( oSelectedRecord != null )
			{
				sConfigurationName = oSelectedRecord.get( 'ConfigurationName' ).replace( oReplaceRegex, "" );
			}

			reference.up( 'panel' ).down( '#ConfigurationName' ).setValue( sConfigurationName );

			reference.up( 'panel' ).down( '#ConfigurationDescription' ).setValue( sThisRecordText );
		};

		this.SubmitDirectConfigSave = function ( button, configurationName, configurationDescription )
		{
			button.up( '#TopLevelBrowser' ).down( '#updateConfigurationName' ).setValue( configurationName );

			button.up( '#TopLevelBrowser' ).down( '#updateConfigurationDescription' ).setValue( configurationDescription );

			button.up( '#TopLevelBrowser' ).down( '#btnSaveConfig' ).fireEvent( 'click' );
		};

		this.SubmitConfigSave = function ( reference, browserGuid, isDirect )
		{
			var oBrowser = FindBrowserByGuid( browserGuid );

			oBrowser.down( '#updateConfigurationName' ).setValue( reference.up( 'panel' ).down( '#ConfigurationName' ).getValue() );

			oBrowser.down( '#updateConfigurationDescription' ).setValue( reference.up( 'panel' ).down( '#ConfigurationDescription' ).getValue() );

			oBrowser.down( '#btnSaveConfig' ).fireEvent( 'click' );

			reference.up( 'window' ).close();
		};

		this.SetConfigurationToBlank = function ( reference )
		{
			var oFilterButton = reference.up( '#TopLevelBrowser' ).down( '#btnBrowserFilter' );

			this.ToggleFilters( oFilterButton, true );

			var oConfiguration = reference.up( '#TopLevelBrowser' ).down( '#ConfigurationIds' );

			var oFirstRecord = oConfiguration.getStore().first();

			oConfiguration.select( oFirstRecord );

			oConfiguration.fireEvent( 'select', oConfiguration, oFirstRecord );
		};

		this.UpdateBrowserConfigurations = function ( reference, result )
		{
			if ( result )
			{
				if ( !result.IsError )
				{
					var oConfiguration = reference.up( '#TopLevelBrowser' ).down( '#ConfigurationIds' );

					var oDeleteButton = reference.up( '#TopLevelBrowser' ).down( '#btnDelete' );

					oConfiguration.getStore().loadData( result.Configurations );

					var oRecord = oConfiguration.getStore().findRecord( 'Ids', result.SelectedConfiguration );

					oConfiguration.select( oRecord );

					oConfiguration.fireEvent( "select", oConfiguration );

					this.CheckDeleteButtonDisabled( oConfiguration, oDeleteButton );
				} else
				{
					if ( result.IsDuplicate )
					{
						Ext.Msg.alert( 'Duplicate Configuration', result.ErrorMessage.FriendlyErrorMessage );
					} else
					{
						Core.ErrorWindow( result.ErrorMessage.DetailedErrorMessage, result.ErrorMessage.FriendlyErrorMessage );
					}
				}
			}
		};

		this.CheckDeleteButtonDisabled = function ( configurationCombobox, deleteButton )
		{
			var oRecord = configurationCombobox.getStore().findRecord( 'Ids', configurationCombobox.getValue() );

			var bSetDeleteButtonDisabled = true;

			if ( oRecord != null )
			{
				var sConfigUserId = configurationCombobox.getStore().findRecord( 'Ids', configurationCombobox.getValue() ).get( "UserId" ).Trim();

				bSetDeleteButtonDisabled = !( sConfigUserId != "ADMIN" && sConfigUserId.length > 0 && parseBool( deleteButton.IsDisabledByAuthorization ) == false );
			}

			deleteButton.setDisabled( bSetDeleteButtonDisabled );
		};

		this.GetBrowserConfigFromIds = function ( configurationCombobox )
		{
			return configurationCombobox.getStore().findRecord( 'Ids', configurationCombobox.getValue() ).get( "ConfigurationId" );
		};

		/*** End Configuration Scripts ***/

		/*** Paging Scripts ***/

		this.GoFirst = function ( button )
		{
			/*orig function: if(this.fireEvent("beforechange",this,1)!==false){this.store.loadPage(1)}*/
			var oThisBrowser = button.up( '#TopLevelBrowser' );
			oThisBrowser.down( '#PageNumber' ).setValue( 1 );
			oThisBrowser.down( '#BrowserPageToLoad' ).setValue( 1 );
			this.CopyStoresToLastJson( button );
			//oThisBrowser.down( '#btnSearch' ).fireEvent( 'click' );
		};

		this.GoPrevPage = function ( button )
		{
			var oThisBrowser = button.up( '#TopLevelBrowser' );

			var bReturnVal = false;

			/*orig function: var c=this,b=c.getPageData().pageCount,a=c.store.currentPage+1;if(a<=b){if(c.fireEvent("beforechange",c,a)!==false){c.store.nextPage()}}*/
			button.setDisabled( true );
			var oPaging = button.up( '#BrowserPaging' ),
				iPageCount = oPaging.getPageData().pageCount,
				iPrevPage = oPaging.store.currentPage - 1;

			var iRemotePageSize = parseInt( oThisBrowser.down( "#BrowserPageSize" ).getValue() );
			var iFullDataCount = parseInt( oThisBrowser.down( "#BrowserFullDataCount" ).getValue() );

			if ( iPrevPage > 0 )
			{
				if ( oPaging.fireEvent( "beforechange", oPaging, iPrevPage ) !== false )
				{
					oPaging.store.previousPage();
					this.PagingDisplayControlsToggle( oPaging );
					Ext.fly( button.up( 'grid' ).getView().getNode( 0 ) ).scrollIntoView();          /*force grid to scroll to top*/
					bReturnVal = true;
				}
			} else if ( parseInt( oThisBrowser.down( '#PageNumber' ).value ) > 1 )
			{
				oThisBrowser.down( "#BrowserPageToLoad" ).setValue( -1 ); /*tells the browser to go to the last local page of the previous remote page*/
				oThisBrowser.down( '#PageNumber' ).setValue( parseInt( oThisBrowser.down( '#PageNumber' ).value ) - 1 );
				this.CopyStoresToLastJson( button );
				bReturnVal = true;
				oThisBrowser.down( '#btnSearch' ).fireEvent( 'click' );
			}

			return bReturnVal;
		};

		this.GoNextPage = function ( button )
		{
			var oThisBrowser = button.up( '#TopLevelBrowser' );

			var bReturnVal = false;

			/*orig function: var c=this,b=c.getPageData().pageCount,a=c.store.currentPage+1;if(a<=b){if(c.fireEvent("beforechange",c,a)!==false){c.store.nextPage()}}*/
			button.setDisabled( true );
			var oPaging = button.up( '#BrowserPaging' ),
				iPageCount = oPaging.getPageData().pageCount,
				NextPage = oPaging.store.currentPage + 1;

			var iRemotePageSize = parseInt( oThisBrowser.down( "#BrowserPageSize" ).getValue() );
			var iFullDataCount = parseInt( oThisBrowser.down( "#BrowserFullDataCount" ).getValue() );

			if ( NextPage <= iPageCount )
			{
				if ( oPaging.fireEvent( "beforechange", oPaging, NextPage ) !== false )
				{
					oPaging.store.nextPage();
					this.PagingDisplayControlsToggle( oPaging );
					Ext.fly( button.up( 'grid' ).getView().getNode( 0 ) ).scrollIntoView();            /*force grid to scroll to top*/

					bReturnVal = true;
				}
			} else
			{
				RemotePage = parseInt( oThisBrowser.down( '#PageNumber' ).value );

				if ( ( RemotePage ) * iRemotePageSize < iFullDataCount )
				{
					oThisBrowser.down( "#BrowserPageToLoad" ).setValue( 1 );
					oThisBrowser.down( '#PageNumber' ).setValue( RemotePage + 1 );
					this.CopyStoresToLastJson( button );
					bReturnVal = true;
					oThisBrowser.down( '#btnSearch' ).fireEvent( 'click' );
				}
			}

			return bReturnVal;
		};

		this.UpdatePageDisplayMessage = function ( paging )
		{
			var oThisBrowser = paging.up( '#TopLevelBrowser' );

			var iRemotePageSize = parseInt( oThisBrowser.down( "#BrowserPageSize" ).getValue() );
			var iFullDataCount = parseInt( oThisBrowser.down( "#BrowserFullDataCount" ).getValue() );

			var remotePage = oThisBrowser.down( '#PageNumber' ).value,
				remotePageSize = iRemotePageSize,
				localPage = paging.store.currentPage,
				localPageSize = paging.store.pageSize;

			var StartNum = ( ( remotePage - 1 ) * remotePageSize ) + ( ( localPage - 1 ) * localPageSize + 1 ),
				ToNum = ( ( remotePage - 1 ) * remotePageSize ) + ( localPage * localPageSize ),
				FullNum = iFullDataCount;

			ToNum = ( ToNum > FullNum ) ? FullNum : ToNum;

			paging.displayMsg
			= "Displaying " + StartNum + " to " + ToNum + " of " + FullNum;
		};

		this.SetPagingItemsVisible = function ( pt, visible, hideMode )
		{
			var method = visible ? "show" : "hide";
			pt.items.each( function ( item, index )
			{
				if ( index < 11 )
				{ /* with the default prependButtons false */
					item.hideMode = hideMode; /* you could set up that initially within, for example, a PagingToolbar AfterRender listener */
					item[method]();
				} else
				{
					return false; /* to stop the each iteration */
				}
			} );
		};

		this.PagingDisplayControlsToggle = function ( reference )
		{
			var oThisBrowser = reference.up( '#TopLevelBrowser' );

			var oPaging = oThisBrowser.down( '#BrowserPaging' ),
				iPageCount = ( oPaging.getPageData() ) ? oPaging.getPageData().pageCount : 0,
				iNextPage = oPaging.store.currentPage + 1,
				iLocalPage = oPaging.store.currentPage,
				iRemotePage = parseInt( oThisBrowser.down( '#PageNumber' ).value ),
				iRemotePageSize = 4,
				oNextButton = oThisBrowser.down( '#BrowserNextButton' ),
				oPrevButton = oThisBrowser.down( '#BrowserPrevButton' );

			var iRemotePageSize = parseInt( oThisBrowser.down( "#BrowserPageSize" ).getValue() );
			var iFullDataCount = parseInt( oThisBrowser.down( "#BrowserFullDataCount" ).getValue() );

			/*set next Button*/

			if ( iPageCount == 0 ) /*this will handle how this is handled the first time it's called, when PageCount is not available (extjs bug)*/
			{
				if ( parseInt( oThisBrowser.down( '#gridpanelComboBoxPaging' ).getValue() ) > iFullDataCount )
				{
					oNextButton.setDisabled( true );
				} else
				{
					oNextButton.setDisabled( false );
				}
			} else if ( iNextPage > iPageCount )
			{
				if ( ( iRemotePage * iRemotePageSize ) > iFullDataCount )
				{
					oNextButton.setDisabled( true );
				} else
				{
					oNextButton.setDisabled( false );
				}
			} else
			{
				oNextButton.setDisabled( false );
			}

			/*set prev Button*/
			if ( iRemotePage == 1 && iLocalPage == 1 )
			{
				oPrevButton.setDisabled( true );
			} else
			{
				oPrevButton.setDisabled( false );
			}

			Core.Browser.UpdatePageDisplayMessage( oPaging );
		};

		/*** End Paging Scripts ***/

		/*** Store Handling ***/

		this.ClearJsonStores = function ( reference )
		{
			var oJsonFilter = reference.up( '#TopLevelBrowser' ).down( '#JsonFilter' );
			var oJsonSort = reference.up( '#TopLevelBrowser' ).down( '#JsonSort' );
			oJsonFilter.setValue( '' );
			oJsonSort.setValue( '' );
		};

		this.FilterStoreToJson = function ( reference )
		{
			var oFilterStore = reference.up( '#TopLevelBrowser' ).down( '#tabFilterCriteria' ).getStore();

			oFilterStore.data.each( function ( item )
			{
				/*commented out for now while admin properties are sorted out
				Note: admin is not the right thing to worry about here - just an example for now*/
				if ( item.data )
				{
					if ( !item.CreateTime )
					{
						item.CreateTime = "1/1/2000 12:00:00";
						item.UpdateTime = "1/1/2000 12:00:00";
					}
				}

				item.Operand2 = item.Operand2DisplayValue;
			} );

			this.StoreToJson( oFilterStore, reference.up( '#TopLevelBrowser' ).down( '#JsonFilter' ) );
		};

		this.StoreToJson = function ( store, control )
		{
			control.setValue( Ext.encode( Ext.pluck( store.data.items, 'data' ) ) );
		}


		this.SortStoreToJson = function ( reference )
		{
			this.StoreToJson( reference.up( '#TopLevelBrowser' ).down( '#tabSortCriteria' ).getStore(), reference.up( '#TopLevelBrowser' ).down( '#JsonSort' ) );
		};

		this.StoresToJson = function ( reference )
		{
			this.FilterStoreToJson( reference );

			this.SortStoreToJson( reference );
		};

		this.CopyStoresToLastJson = function ( reference )
		{
			reference.up( '#TopLevelBrowser' ).down( '#BrowserLastFilterJson' ).setValue( reference.up( '#TopLevelBrowser' ).down( '#JsonFilter' ).getValue() );

			reference.up( '#TopLevelBrowser' ).down( '#BrowserLastSortJson' ).setValue( reference.up( '#TopLevelBrowser' ).down( '#JsonSort' ).getValue() );
		};

		/*** End Store Handling ***/

		/*** Filter/Sort Scripts ***/

		this.ApplyCommandtoGrid = function ( command, grid, record )
		{
			if ( command == "Delete" )
			{
				if ( !record.data.FixedFlag )
				{
					grid.getStore().remove( record );

					this.StoresToJson( grid );
				} else
				{
					window.alert( "You can't remove this filter" );
				}
			}
		};

		this.LaunchFillBrowser = function ( button )
		{
			var oGrid = button.column.grid;

			var oRecord = button.column.record;

			var sBrowserGuid = oGrid.up( '#TopLevelBrowser' ).down( '#BrowserGuid' ).getValue();

			var sBrowserColumnsItemId = 'BrowserColumns' + sBrowserGuid;

			var oFillBrowser = this.GetNestedBrowserInFilter( sBrowserColumnsItemId, oRecord.get( "Operand1" ) );

			var iIndex = oGrid.getStore().indexOf( oRecord );

			var oFillField = this.FindFilterGridComponent( oGrid, oRecord.id, 3 ); /*(columns 3 is Operand 2 (value) field)*/

			var oLaunchArg = {};

			oLaunchArg.QueryKey = oFillField.id;

			oLaunchArg.DataColumn = oFillBrowser.BrowserColumn;

			oLaunchArg.isLookup = false;

			var sLaunchArg = JSON.stringify( oLaunchArg );
			sLaunchArg = "[" + sLaunchArg + "]";

			LaunchBrowserById( oFillBrowser.BrowserId, oFillBrowser.BrowserConfigurationId, "", "FillTextForFilter", sLaunchArg, Core.Ext.TopLevelContainerId( oGrid ), oFillField.id );
		};

		this.AddFilter = function ( button )
		{
			var oMe = this;

			var iBrowserId = button.up( '#TopLevelBrowser' ).down( '#BrowserId' ).getValue();

			var oFilterGrid = button.up( '#tabFilterSortPanel' ).down( '#tabFilterCriteria' );

			oFilterGrid.store.add( {
				Operator: '='
									  , LiteralFlag: true
									  , LogicalOperator: 'AND'
									  , FixedFlag: false
									  , CreateTime: '1/1/0001 12:00:00AM'
									  , UpdateTime: '1/1/0001 12:00:00AM'
									  , BrowserIdKey: iBrowserId
			} );

			FilterStoreToJson( button );

			if ( oFilterGrid.store.data.items.length > 0 )
			{
				sRecordId = oFilterGrid.getStore().data.getAt( oFilterGrid.store.data.items.length - 1 ).id;

				setTimeout( function ()
				{
					oMe.FocusOnFilterGridComponent( oFilterGrid, sRecordId, 3 );
				},
						   250
					);
			}
		};

		this.AddSort = function ( button )
		{
			var SortGrid = button.up( '#tabFilterSortPanel' ).down( '#tabSortCriteria' );
			SortGrid.store.add( {
				SortOrder: 'A'
								   , CreateTime: '1/1/0001 12:00:00AM'
								   , UpdateTime: '1/1/0001 12:00:00AM'
			} );

			SortStoreToJson( button );

			SortGrid.getSelectionModel().select( SortGrid.store.data.items.length - 1 );
		};

		this.ShowHideAddButton = function ( TabContainer )
		{
			switch ( TabContainer.activeTab.itemId )
			{
				case "tabFilterCriteria":
					TabContainer.down( '#AddFilterButton' ).show();
					TabContainer.down( '#AddSortButton' ).hide();
					break;
				case "tabSortCriteria":
					TabContainer.down( '#AddFilterButton' ).hide();
					TabContainer.down( '#AddSortButton' ).show();
					break;
				case "tabSqlCriteria":
					TabContainer.down( '#AddFilterButton' ).hide();
					TabContainer.down( '#AddSortButton' ).hide();
					break;
			}
		};

		this.ToggleFilters = function ( button, forceOpen )
		{
			var panel = button.up( '#panelBrowserFilter' );

			var isCollapsed = panel.getCollapsed();

			if ( isCollapsed != false ) /*note: getCollapsed returns either false or the collapse direction*/
			{
				button.setIconCls( '#SectionExpanded' );
			} else
			{
				button.setIconCls( '#SectionCollapsed' );
			}

			if ( forceOpen && isCollapsed == false )
			{
			} else
			{
				panel.toggleCollapse();
			}

			setTimeout( function ()
			{
				if ( panel.up( '#TopLevelBrowser' ) )
				{
					CheckBrowserHeight( panel.up( '#TopLevelBrowser' ) );
				}
			}
					   , 500 );
		};

		this.FocusTextboxAtEnd = function ( textbox )
		{
			var sValue = textbox.getValue();
			textbox.setValue( '' );
			textbox.setValue( sValue );
		};

		this.ActiveTabFocus = function ( activeTab )
		{
			switch ( activeTab.itemId )
			{
				case "tabFilterCriteria":

					var sRecordId = "";

					for ( var i = 0; i < activeTab.getStore().data.items.length ; i++ )
					{
						if ( activeTab.getStore().data.getAt( i ).get( 'FixedFlag' ) == false )
						{
							sRecordId = activeTab.getStore().data.getAt( i ).id;

							this.FocusOnFilterGridComponent( activeTab, sRecordId, 3 );

							break;
						}
					}

					break;
				case "tabSortCriteria":

					activeTab.getSelectionModel().select( 0 );

					break;
				case "tabSqlCriteria":

					break;
			}
		};

		this.ActiveTabFocusOnRender = function ( activeTab )
		{
			var oMe = this;

			switch ( activeTab.itemId )
			{
				case "tabFilterCriteria":

					var iCounter = 0;
					var FindTextbox = function ()
					{
						var maxCount = 10;
						var bFoundTextbox = false;

						for ( var i = 0; i < activeTab.getStore().data.items.length ; i++ )
						{
							if ( activeTab.columns[3].cache.length > 0
								&& activeTab.columns[3].cache[i].cmp
								&& activeTab.getStore().data.getAt( i ).get( 'FixedFlag' ) == false )
							{
								var sRecordId = activeTab.getStore().data.getAt( i ).id;

								oMe.FocusOnFilterGridComponent( activeTab, sRecordId, 3 );

								bFoundTextbox = true;
								break;
							}
						}

						iCounter++;

						if ( bFoundTextbox || iCounter >= maxCount )
						{
							clearInterval( oFindTextbox );
						}
					};

					var oFindTextbox = setInterval( FindTextbox, 500 );

					break;
				case "tabSortCriteria":

					activeTab.getSelectionModel().select( 0 );

					break;
				case "tabSqlCriteria":

					activeTab.down;
					break;
			}
		};

		this.FindFilterGridComponent = function ( grid, recordId, columnIndex )
		{
			var iCacheLength = grid.columns[1].cache.length - 1;

			var i = iCacheLength;

			for ( i ; i >= 0 ; i-- )
			{
				if ( recordId == grid.columns[1].cache[i].id )
				{
					var oComponent = grid.columns[columnIndex].cache[i].cmp;

					return oComponent;
				}
			}
		};

		this.FocusOnFilterGridComponent = function ( grid, recordId, columnIndex )
		{
			var oComponent = this.FindFilterGridComponent( grid, recordId, columnIndex );

			oComponent.focus();

			if ( oComponent.xtype == "textfield" )
			{
				this.FocusTextboxAtEnd( oComponent );
			}
		};

		this.BlurFilterGridComponent = function ( grid, recordId, columnIndex )
		{
			var oComponent = FindFilterGridComponent( grid, recordId, columnIndex );
			/* extJs .blur() on seelctbox doesn't properly remove classes */
			if ( oComponent.xtype == "selectbox" )
			{
				oComponent.collapse();
				oComponent.bodyEl.removeCls( "form-focus x-field-focus x-form-trigger-wrap-focus x-form-focus x-field-form-focus x-field-default-form-focus" );
				oComponent.inputEl.removeCls( "form-focus x-field-focus x-form-trigger-wrap-focus x-form-focus x-field-form-focus x-field-default-form-focus" );
			}
			oComponent.blur();
		};

		this.CheckOperatorFromComponent = function ( selectbox, e )
		{
			var iIndex = selectbox.column.rowIndex;

			var oGrid = selectbox.column.grid;

			var sRecordId = oGrid.getStore().getAt( iIndex ).id;

			var sOperatorValue = this.FindFilterGridComponent( oGrid, sRecordId, 2 );

			this.CheckOperator( sOperatorValue );
		};

		this.CheckIfFocusOnFilterRow = function ( grid, recordId, targetId )
		{
			var iCacheLength = grid.columns[1].cache.length - 1;

			var i = iCacheLength;

			for ( i ; i >= 0 ; i-- )
			{
				for ( var j = 1 ; j < 7 ; j++ )
				{
					if ( j != 4 && grid.columns[j].cache[i].cmp.id == targetId && grid.columns[j].cache[i].id == recordId )
					{
						var oComponent = grid.columns[j].cache[i].cmp;

						return j;
					}
				}
			}

			return null;
		};

		this.IsNestedBrowser = function ( grid, record )
		{
			var bIsNestedBrowser = false;

			if ( record.get( "Operand1" ) != "" )
			{
				var sBrowserGuid = grid.up( '#TopLevelBrowser' ).down( '#BrowserGuid' ).getValue();

				var sBrowserColumnsItemId = 'BrowserColumns' + sBrowserGuid;

				var bIsNestedBrowser = this.GetNestedBrowserInFilter( sBrowserColumnsItemId, record.get( "Operand1" ) ).IsNestedBrowser;
			}

			return bIsNestedBrowser;
		};

		this.CheckForNestedBrowserRender = function ( button )
		{
			var iIndex = button.column.rowIndex;

			var oGrid = button.column.grid;

			var oRecord = oGrid.getStore().getAt( iIndex );

			var bIsNestedBrowser = this.IsNestedBrowser( oGrid, oRecord );

			bIsNestedBrowser ? button.show() : button.hide();
		};

		this.CheckForNestedBrowserInFilter = function ( selectbox, e )
		{
			var iIndex = selectbox.column.rowIndex;

			var oGrid = selectbox.column.grid;

			var sRecordId = oGrid.getStore().getAt( iIndex ).id;

			//var iKeyCode = ( e ) ? e.keyCode : 0;

			//var target = Ext.Element.getActiveElement();

			//var iSameRowColumnIndex = iKeyCode ? 0 : CheckIfFocusOnFilterRow( oGrid, sRecordId, target.name );

			//new stuff
			var oRecord = oGrid.getStore().getAt( iIndex );

			var oComponent = this.FindFilterGridComponent( oGrid, sRecordId, 4 );

			var bIsNestedBrowser = this.IsNestedBrowser( oGrid, oRecord );

			bIsNestedBrowser ? oComponent.show() : oComponent.hide();

			var oTextfield = this.FindFilterGridComponent( oGrid, sRecordId, 3 );

			this.FilterValueHandling( oTextfield, null );
		};

		this.GetNestedBrowserInFilter = function ( storeId, columnId )
		{
			var oNestedBrowser = {};

			var oStore = Ext.StoreManager.lookup( storeId );

			oNestedBrowser.IsNestedBrowser = oStore.findRecord( 'Expression', columnId ).get( 'NestedBrowserFlag' );
			oNestedBrowser.BrowserId = oStore.findRecord( 'Expression', columnId ).get( 'NestedBrowserId' );
			oNestedBrowser.BrowserColumn = oStore.findRecord( 'Expression', columnId ).get( 'NestedBrowserColumn' );
			oNestedBrowser.BrowserConfigurationId = oStore.findRecord( 'Expression', columnId ).get( 'NestedConfigurationId' );

			return oNestedBrowser;
		};

		this.CheckOperator = function ( selectbox )
		{
			var iIndex = selectbox.column.rowIndex;

			var oGrid = selectbox.column.grid;

			var sRecordId = oGrid.getStore().getAt( iIndex ).id;

			var sSelectboxValue = selectbox.getValue();

			var oNameField = this.FindFilterGridComponent( oGrid, sRecordId, 1 );

			var oValueField = this.FindFilterGridComponent( oGrid, sRecordId, 3 );

			switch ( sSelectboxValue )
			{
				case "IS NULL":
				case "IS NOT NULL":

					var oValueField = this.FindFilterGridComponent( oGrid, sRecordId, 3 );

					oValueField.setValue( "" );

					break;
				case "(":
				case ")":

					oNameField.setValue( "" );

					oValueField.setValue( "" );

					break;
				default:

					break;
			}
		};

		this.FilterKeyHandling = function ( reference, e )
		{
			var oMe = this;

			var sRecordId = reference.record.id;

			var oGrid = reference.column.grid;

			var oColumn = reference.column;

			var oColumns = oGrid.columns;

			var sDataIndex = oColumn.column.dataIndex;

			var iColumnIndex = 0;

			for ( var i = 0; i < oColumns.length; i++ )
			{
				if ( oColumns[i] != "imagecommandcolumn" && oColumns[i].dataIndex == sDataIndex )
				{
					iColumnIndex = i;
				}
			}

			var iNewColumnIndex = 0;

			//var iRowIndex = oColumn.rowIndex;
			var iRowIndex = oGrid.getStore().indexOf( oColumn.record );

			var iNewRowIndex = 0;

			var iLastRowIndex = oGrid.getStore().data.items.length - 1;

			if ( !e.browserEvent.repeat )
			{
				switch ( e.keyCode )
				{
					case 9:

						if ( reference.xtype == "selectbox" )
						{
							if ( reference.isExpanded )
							{
								var sHighlightedValue = null;
								try
								{
									sHighlightedValue = reference.getStore().getAt( reference.getPicker().highlightedItem.viewIndex ).get( "field1" );
								} catch ( err )
								{
									sHighlightedValue = null;
								}
								if ( sHighlightedValue != null )
								{
									reference.setValue( sHighlightedValue );
								}
								//reference.blur()
							}
						}
						/* Handle extjs bug where tab focus doesn't change when all rows are removed and then added */
						if ( iRowIndex == 0 && reference.record.get( "ConfigurationIdKey" ) == 0 )
						{
							if ( e.shiftKey )
							{
								switch ( iColumnIndex )
								{
									case 0:

										iNewColumnIndex = 0;
										break;
									case 1:

										iNewColumnIndex = 1;
										break;
									case 5:

										iNewColumnIndex = 3;
										break;
									default:

										iNewColumnIndex = iColumnIndex - 1;
										break;
								}
							} else
							{
								switch ( iColumnIndex )
								{
									case 0:

										iNewColumnIndex = 0;
										break;
									case 3:

										iNewColumnIndex = 5;
										break;
									case 6:

										iNewColumnIndex = 1;
										iNewRowIndex = iRowIndex + 1;
										break;
									default:

										iNewColumnIndex = iColumnIndex + 1;
										break;
								}
							}

							if ( iColumnIndex != 6 )
							{
								oMe.FocusOnFilterGridComponent( oGrid, sRecordId, iNewColumnIndex );

								oMe.BlurFilterGridComponent( oGrid, sRecordId, iColumnIndex );
							}
						}

						break;
					case 13:

						var bSearch = true;

						if ( reference.xtype == "selectbox" )
						{
							if ( reference.isExpanded )
							{
								bSearch = false;
							}
						}
						if ( bSearch )
						{
							this.CopyStoresToLastJson( reference.column.grid );

							oGrid.up( '#TopLevelBrowser' ).down( '#btnFind' ).fireEvent( 'click' );
						}
						break;
					case 37:

						//left

						switch ( iColumnIndex )
						{
							case 0:

								iNewColumnIndex = 0;
								break;
							case 1:

								iNewColumnIndex = 6;
								break;
							case 5:

								iNewColumnIndex = 3;
								break;
							case 1:

								iNewColumnIndex = 6;
								break;
							default:

								iNewColumnIndex = iColumnIndex - 1;
								break;
						}

						if ( iNewColumnIndex > 0 )
						{
							var bFocus = true;

							if ( reference.xtype == "textfield" )
							{
								var sValue = reference.getValue().length;
								var iEndPos = reference.inputEl.dom.selectionEnd;

								if ( iEndPos > 0 )
								{
									bFocus = false;
								}
							}

							if ( bFocus )
							{
								oMe.FocusOnFilterGridComponent( oGrid, sRecordId, iNewColumnIndex );

								oMe.BlurFilterGridComponent( oGrid, sRecordId, iColumnIndex );
							}
						}

						break;
					case 38:

						//up

						var bFocus = true;
						if ( reference.xtype == "selectbox" && reference.isExpanded )
						{
							bFocus = false;
						}

						if ( bFocus )
						{
							iNewRowIndex = iRowIndex - 1 < 0 ? iLastRowIndex : iRowIndex - 1;

							sNewRecordId = oGrid.getStore().data.get( iNewRowIndex ).id;

							sOldRecordId = oGrid.getStore().data.get( iRowIndex ).id;

							oMe.FocusOnFilterGridComponent( oGrid, sNewRecordId, iColumnIndex );

							oMe.BlurFilterGridComponent( oGrid, sOldRecordId, iColumnIndex );
						}

						break;
					case 39:

						//right

						switch ( iColumnIndex )
						{
							case 0:

								iNewColumnIndex = 0;
								break;
							case 3:

								iNewColumnIndex = 5;
								break;
							case 6:

								iNewColumnIndex = 1;
								break;
							default:

								iNewColumnIndex = iColumnIndex + 1;
								break;
						}

						if ( iNewColumnIndex > 0 )
						{
							var bFocus = true;
							if ( reference.xtype == "textfield" )
							{
								var sValue = reference.getValue().length;
								var iEndPos = reference.inputEl.dom.selectionEnd;
								var iStartPos = reference.inputEl.dom.selectionStart;

								if ( iEndPos < sValue || iEndPos != iStartPos )
								{
									bFocus = false;
								}
							}

							if ( bFocus )
							{
								oMe.FocusOnFilterGridComponent( oGrid, sRecordId, iNewColumnIndex );

								oMe.BlurFilterGridComponent( oGrid, sRecordId, iColumnIndex );
							}
						}

						break;
					case 40:

						//down

						var bFocus = true;
						if ( reference.xtype == "selectbox" )
						{
							if ( reference.isExpanded )
							{
								bFocus = false;
							} else
							{
								e.preventDefault();
							}
						}

						if ( bFocus )
						{
							iNewRowIndex = iRowIndex + 1 > iLastRowIndex ? 0 : iRowIndex + 1;

							sNewRecordId = oGrid.getStore().data.get( iNewRowIndex ).id;

							sOldRecordId = oGrid.getStore().data.get( iRowIndex ).id;

							oMe.FocusOnFilterGridComponent( oGrid, sNewRecordId, iColumnIndex );

							oMe.BlurFilterGridComponent( oGrid, sOldRecordId, iColumnIndex );
						}
						break;
				}
			}

			PreventBackspace( reference, e );
		};

		this.FilterValueHandling = function ( reference )
		{
			var oRecord = reference.record;

			var sColumnId = oRecord.get( "Operand1" );

			var sOperator = oRecord.get( "Operator" );

			var oGrid = reference.column.grid;

			var sBrowserGuid = oGrid.up( '#TopLevelBrowser' ).down( '#BrowserGuid' ).getValue();

			var sBrowserColumnsStoreId = 'BrowserColumns' + sBrowserGuid;

			var oStore = Ext.StoreManager.lookup( sBrowserColumnsStoreId );

			if ( sColumnId.Trim() != "" )
			{
				var iAdoDataType = parseInt( oStore.findRecord( 'Expression', sColumnId ).get( 'AdoDatatype' ) );

				var sOriginalValue = reference.getValue();

				var sAddToPattern = "";

				switch ( sOperator )
				{
					case "IS NULL":
					case "IS NOT NULL":
					case "(":
					case ")":

						reference.setValue( "" );

						break;
					case "IN":
					case "NOT IN":
					case "BETWEEN":

						break;
					default:

						switch ( iAdoDataType )
						{
							case 11: //   Bit

								sStartsWithTruePattern = /^[1YT]/i;
								sStartsWithFalsePattern = /^[0NF]/i;

								if ( sStartsWithTruePattern.test( sOriginalValue.Trim() ) )
								{
									reference.setValue( "True" );
								} else if ( sStartsWithFalsePattern.test( sOriginalValue.Trim() ) )
								{
									reference.setValue( "False" );
								} else
								{
									reference.setValue( "" );
								}

								break;
							case 129: //   Char
							case 130: //   NChar
							case 200: //   VarChar
							case 202: //   NVarChar

								break;
							case 7: //   Date
							case 135: //   DateTime

								break;
							case 6: //   Currency
							case 14: //   Decimal
							case 5: //   Float
							case 131: //   Numeric
							case 4: //   Real.

								var sValue = sOriginalValue.replace( /[\$£¥ ,]*/g, "" );

								sNumericPattern = /^[0-9.]*$/;

								if ( sNumericPattern.test( sValue ) )
								{
									if ( sOriginalValue != sValue )
									{
										reference.setValue( sValue );
									}
								} else
								{
									sValue = sOriginalValue.replace( /[^0-9\.]/g, "" );
									reference.setValue( sValue );
								}

								break;
							case 17: //   TinyInt
							case 3: //   Int
							case 2: //   SmallInt
							case 20: // BigInt

								sIntegerPattern = /^[0-9]*$/;

								if ( sIntegerPattern.test( sOriginalValue ) )
								{
									//reference.setValue( sValue );
								} else
								{
									sValue = sOriginalValue.replace( /[^0-9]/g, "" );
									reference.setValue( sValue );
								}

								break;
							case 201: //   Text
							case 203: //   NText

								break;
							case 128: //   Binary
							case 12: //   SqlVariant
							case 205: //   Image
							case 72: //   UniqueIdentifier
							case 204: //   VarBinary

								break;
						}

						break;
				}
			} else
			{
				switch ( sOperator )
				{
					case "IS NULL":
					case "IS NOT NULL":
					case "(":
					case ")":

						reference.setValue( "" );

						break;
				}
			}
		};

		/*** End Filter/Sort Scripts ***/

		/*** Launching Scripts ***/

		this.GetJsonLaunchArguments = function ( launchArguments )
		{
			var oLaunchArguments;

			if ( typeof JSON !== 'undefined' )
			{
				try
				{
					oLaunchArguments = JSON.parse( launchArguments );
				} catch ( err )
				{
					oLaunchArguments = JSON.parse( "[]" );
				}
			} else
			{
				alert( "Your browser doesn't support JSON\n\nIf you are using IE 8+, please turn off compatibility mode" );
			}

			return oLaunchArguments;
		};

		this.GetValueFromLaunchArguments = function ( jsonLaunchArguments, record, queryKey )
		{
			var oValue = null;

			for ( i = 0; i < jsonLaunchArguments.length; i++ )
			{
				if ( jsonLaunchArguments[i].QueryKey.toLowerCase() == queryKey.toLowerCase() )
				{
					oValue = record.get( jsonLaunchArguments[i].DataColumn );

					break;
				}
			}

			return oValue;
		};

		this.GetLaunchArguments = function ( record, grid )
		{
			var sLaunchData = "";

			var oLaunchArguments = JSON.parse( grid.up( "#TopLevelBrowser" ).down( "#BrowserLaunchArguments" ).getValue() );

			for ( var i = 0; i < oLaunchArguments.length; i++ )
			{
				sLaunchData += record.get( oLaunchArguments[i].QueryKey );
				if ( i > 0 )
				{
					sLaunchData += "/";
				}
			}

			return sLaunchData;
		};

		this.FillText = function ( reference, record )
		{
			var sOpenerReference = reference.up( '#TopLevelBrowser' ).down( '#ReferenceObjectForFill' ).value,
				oWindowReference = Ext.ComponentQuery.query( '#' + sOpenerReference )[0].up( 'form' );

			var sLaunchArguments = reference.up( '#TopLevelBrowser' ).down( '#BrowserLaunchArguments' ).getValue();

			oLaunchArguments = GetJsonLaunchArguments( sLaunchArguments );

			for ( var i = 0; i < oLaunchArguments.length; i++ )
			{
				var oField = oWindowReference.down( '[itemId=' + oLaunchArguments[i].QueryKey + ']' );

				oField.setValue( record.get( oLaunchArguments[i].DataColumn ) );
			}

			var oWindow = reference.up( 'window' );

			oWindow.close();
		};

		this.FillTextForFilter = function ( reference, record )
		{
			var sOpenerReference = reference.up( '#TopLevelBrowser' ).down( '#ReferenceObjectForFill' ).value;

			var sLaunchArguments = reference.up( '#TopLevelBrowser' ).down( '#BrowserLaunchArguments' ).getValue();

			oLaunchArguments = GetJsonLaunchArguments( sLaunchArguments );

			if ( bUseExtNetWindows )
			{
				for ( var i = 0; i < oLaunchArguments.length; i++ )
				{
					Ext.ComponentQuery.query( '#' + sOpenerReference )[0].setValue( record.get( oLaunchArguments[i].DataColumn ) );
				}

				var oWindow = reference.up( 'window' );
				oWindow.close();
			} else
			{
				for ( var i = 0; i < oLaunchArguments.length; i++ )
				{
					window.opener.Ext.ComponentQuery.query( '#' + sOpenerReference )[0].setValue( record.get( oLaunchArguments[i].DataColumn ) );
				}

				window.close();
			}
		};

		this.OpenFormWindow = function ( reference, record, providedLaunchArguments )
		{
			var sLaunchFormBase =
				reference != null
				? reference.up( '#TopLevelBrowser' ).down( '#BrowserLaunchForm' ).getValue()
				: "";
			var sLaunchArguments =
				reference != null
				? reference.up( '#TopLevelBrowser' ).down( '#BrowserLaunchArguments' ).getValue()
				: providedLaunchArguments;

			oLaunchArguments = GetJsonLaunchArguments( sLaunchArguments );

			if ( sLaunchFormBase.Trim() == "" )
			{
				if ( sLaunchFormBase == "" )
				{
					/*we are launching dynamically*/
					//var oBrowserDynamicLaunchJson = JSON.parse( sDynamicLaunchJson );
					var oDynamicLaunch = {};

					var iRecord = GetValueFromLaunchArguments( oLaunchArguments, record, "doc_ref" );

					var sDocType = GetValueFromLaunchArguments( oLaunchArguments, record, "doc_type" );

					var oDynamicLaunch = App.ContainerLaunchStore.findRecord( 'DocumentType', sDocType );

					var oContainer = App.ContainerStore.findRecord( 'Name', oDynamicLaunch.get( "DocumentContainer" ) );

					var iHeight = oContainer ? oContainer.get( 'Height' ) : 800;
					var iWidth = oContainer ? oContainer.get( 'Width' ) : 800;

					var oWindow = window.open( '', '_blank', 'width=' + iWidth + ', height = ' + iHeight + ',resizable=yes,location=no,menubar=no' );

					Ext.net.DirectMethod.request( {
						url: sRoot + "Clearview/GetDynamicLaunchInfo",
						cleanRequest: true,
						params: {
							"token": App.Token.getValue(),
							"table": oDynamicLaunch.get( "DocumentTable" ),
							"primaryKey1": oDynamicLaunch.get( "DocumentPrimaryKey1" ),
							"primaryKey2": oDynamicLaunch.get( "DocumentPrimaryKey2" ),
							"primaryKey3": oDynamicLaunch.get( "DocumentPrimaryKey3" ),
							"primaryKey4": oDynamicLaunch.get( "DocumentPrimaryKey4" ),
							"primaryKey5": oDynamicLaunch.get( "DocumentPrimaryKey5" ),
							"record": iRecord
						},
						success: function ( result )
						{
							if ( !result.IsError )
							{
								var iDynamicRecordDataLength = result.DynamicLaunchData.length;

								if ( iDynamicRecordDataLength > 0 )
								{
									var oDynamicRecordData = result.DynamicLaunchData[0];

									var sQueryString = "?SESSIONTOKEN=" + App.Token.getValue() + "&USESOAP=" + App.UseSoap.getValue();

									for ( var key in oDynamicLaunch.data )
									{
										if ( key.indexOf( "PrimaryKey" ) > 0 )
										{
											if ( oDynamicLaunch.data[key].Trim() != "" )
											{
												sQueryString += "&" + oDynamicLaunch.data[key] + "=" + oDynamicRecordData[oDynamicLaunch.data[key]];
											}
										}
									}

									var sLaunchForm = BuildLaunchForm( oDynamicLaunch.get( "DocumentContainer" ) );

									var sLaunchLocation = sLaunchForm + sQueryString;

									oWindow.location = sLaunchLocation;
									oWindow.focus();
								} else
								{
									var sDetailedMessage = "Could not find a record selecting by the keys: ";

									for ( var key in oDynamicLaunch.data )
									{
										sDetailedMessage += oDynamicLaunch.data[key] + "<br\>";
									}

									Core.ErrorWindow( sDetailedMessage, "Record Not Found" );
									oWindow.close();
								}
							} else
							{
								Core.ErrorWindow( result.ErrorMessage.DetailedErrorMessage, result.ErrorMessage.FriendlyErrorMessage );
								oWindow.close();
							}
						}
					} );
				}
			} else
			{
				var sLaunchForm = BuildLaunchForm( sLaunchFormBase );

				var sQueryString = "?SESSIONTOKEN=" + App.Token.getValue() + "&USESOAP=" + App.UseSoap.getValue();

				for ( var i = 0; i < oLaunchArguments.length; i++ )
				{
					sQueryString += "&" + oLaunchArguments[i].QueryKey + "=" + record.get( oLaunchArguments[i].QueryKey );
				}

				var sLaunchLocation = sLaunchForm + sQueryString;

				var oContainer = App.ContainerStore.findRecord( 'Name', sLaunchFormBase );

				var iHeight = oContainer ? oContainer.get( 'Height' ) : 800;
				var iWidth = oContainer ? oContainer.get( 'Width' ) : 800;

				window.open( sLaunchLocation, '_blank', 'width=' + iWidth + ',height=' + iHeight + ',resizable=yes,location=no,menubar=no' );
			}
		};

		this.BuildLaunchForm = function ( launchForm )
		{
			var oUriFromRoot = new URI( sModelRoot );

			var sLaunchUrl = "";

			launchForm = launchForm.indexOf( "/" ) == 0 ? launchForm : "/" + launchForm;

			launchForm = launchForm.indexOf( ".aspx" ) > 0 ? launchForm : launchForm + ".aspx";

			var sBaseUrl = oUriFromRoot.hostname() == "localhost" ? "http://localhost/Clearview" : oUriFromRoot.href().replace( "/Sunrise/", "" );

			sBaseUrl = launchForm.indexOf( "OCX" ) > 0 ? sBaseUrl + "/CVClient/OCXForms" : sBaseUrl;

			sLaunchUrl = sBaseUrl + launchForm;

			return sLaunchUrl;
		};

		this.OpenFormWindowFromButton = function ( reference )
		{
			var oBrowserGrid = reference.up( '#TopLevelBrowser' ).down( '#gridpanelBrowserResults' );

			var oRow = FindSelectedRow( reference );

			if ( oRow )
			{
				OpenFormWindow( reference, oRow );
			}
		};

		this.BuildExtraFilters = function ( reference )
		{
			var oNestedBrowserLaunchArguments = reference.up( '#TopLevelBrowser' ).down( '#BrowserNestedBrowserLaunchArguments' );

			var oLaunchArguments = JSON.parse( oNestedBrowserLaunchArguments.getValue() );

			var oExtraFilters = [];

			for ( i = 0; i < oLaunchArguments.length; i++ )
			{
				var oBrowserParameter = {};

				oBrowserParameter.Key = oLaunchArguments[i].QueryKey;

				if ( oLaunchArguments[i].isLookup = true )
				{
					oBrowserParameter.Value = FindSelectedItem( reference, oLaunchArguments[i].DataColumn );
				} else
				{
					oBrowserParameter.Value = oLaunchArguments[i].DataColumn;
				}

				oExtraFilters.push( oBrowserParameter );
			}

			return oExtraFilters;
		};

		this.LaunchBrowserInBrowserWindowById = function ( reference, clickType )
		{
			var sBrowserId = reference.up( '#TopLevelBrowser' ).down( '#BrowserNestedBrowserId' ).getValue();
			var iSearchBrowserConfig = reference.up( '#TopLevelBrowser' ).down( '#BrowserNestedBrowserConfigId' ).getValue();
			var sExtraFilters = JSON.stringify( BuildExtraFilters( reference ) );
			var sReferenceObject = Core.Ext.TopLevelContainerId( reference );
			var sReferenceObjectForFill = reference.id;

			LaunchBrowserById( sBrowserId, iSearchBrowserConfig, sExtraFilters, clickType, "", sReferenceObject, sReferenceObjectForFill );
		};

		this.LaunchBrowserById = function ( browserId, searchBrowserConfig, extraFilters, clickType, launchArg, referenceObject, referenceObjectForFill )
		{
			if ( bUseExtNetWindows )
			{
				var oConfigurations = {};

				Ext.net.DirectMethod.request( {
					url: sRoot + "Clearview/OpenBrowserWindowById",
					cleanRequest: true,
					params: {
						browserId: browserId
	, searchBrowserConfig: searchBrowserConfig
	, extraFilters: extraFilters
	, clickType: clickType
	, launchArg: launchArg
	, referenceObject: referenceObject
	, referenceObjectForFill: referenceObjectForFill
	, token: App.Token.getValue()
					}
												 ,
					success: function ( result )
					{
						if ( result.IsError )
						{
							Core.ErrorWindow( result.DetailedErrorMessage, null );
						}
						;
					},
					failure: function ( result )
					{
						Core.ErrorWindow( "Unknown Error opening Browser Window", "Unknown Error opening Browser Window" );
					}
				} );
			} else
			{
				var sLaunchUrl =
					Ext.String.format( "{0}Clearview/BrowserWindowById?token={1}&browserId={2}&searchBrowserConfig={3}&extraFilters={4}&clickType={5}&launchArg={6}&referenceObject={7}&referenceObjectForFill={8}&autoFetch=true"
									  , sRoot
									  , encodeURIComponent( App.Token.getValue() )
									  , browserId
									  , searchBrowserConfig
									  , extraFilters
									  , clickType
									  , launchArg
									  , referenceObject
									  , referenceObjectForFill );

				var sContainerName = Ext.String.format( "FPWebBrowserOCX.FPBrowserOCX.{0}", browserId );

				var oContainer = App.ContainerStore.findRecord( 'Name', sContainerName );

				var iHeight = oContainer ? oContainer.get( 'Height' ) : 800;
				var iWidth = oContainer ? oContainer.get( 'Width' ) : 800;

				window.open( sLaunchUrl, "_blank", "height=" + iHeight + ",width=" + iWidth + ",resizable=yes,location=no,menubar=no,scrollbars=no" );
			}
		};

		this.GetContextLaunchParameters = function ( launchParametersAsJson, record )
		{
			var sLaunchParameters = "?SESSIONTOKEN=" + App.Token.getValue() + "&USESOAP=" + App.UseSoap.getValue();

			for ( var i = 0; i < launchParametersAsJson.length; i++ )
			{
				sLaunchParameters += "&" + launchParametersAsJson[i].QueryKey + "=";

				if ( launchParametersAsJson[i].IsLookup )
				{
					sLaunchParameters += record.get( launchParametersAsJson[i].DataColumn );
				} else
				{
					sLaunchParameters += launchParametersAsJson[i].DataColumn;
				}
			}

			return sLaunchParameters;
		};

		this.EnterKeyDownLaunch = function ( reference, record, event, functionToPerform, index, browserGuid )
		{
			switch ( event.keyCode )
			{
				case 32:

					var oContextMenu = Ext.ComponentQuery.query( "#BrowserContextMenu" + browserGuid )[0];

					if ( oContextMenu && oContextMenu.items.length > 0 )
					{
						BrowserContextMenu( reference, index, event, browserGuid );
					}

					return false;
					break;
				case 33:

					event.preventDefault();

					var oThisBrowser = reference.up( '#TopLevelBrowser' );
					var oPrevButton = oThisBrowser.down( '#BrowserPrevButton' );
					var bPageChanged = GoPrevPage( oPrevButton );

					if ( bPageChanged )
					{
						oThisBrowser.down( '#BrowserLastSelectedIndex' ).setValue( 0 );
						setTimeout( function ()
						{
							FocusOnSelectedRowIndex( oThisBrowser.down( '#gridpanelBrowserResults' ).getView() );
						}, 10 );
					}

					break;
				case 34:

					event.preventDefault();

					var oThisBrowser = reference.up( '#TopLevelBrowser' );
					var oNextButton = oThisBrowser.down( '#BrowserNextButton' );
					var bPageChanged = GoNextPage( oNextButton );

					if ( bPageChanged )
					{
						oThisBrowser.down( '#BrowserLastSelectedIndex' ).setValue( 0 );
						setTimeout( function ()
						{
							FocusOnSelectedRowIndex( oThisBrowser.down( '#gridpanelBrowserResults' ).getView() );
						}, 10 );
					}

					break;
				case 37:
				case 39:

					return ( false );

					// $( 'html, body' ).stop().animate( "scrollLeft", 1000 );

					event.preventDefault();

					break;
				case 38:

					var iCurrentRecordIndex = record.store.indexOf( record );
					var iRecordsOnPageAsIndex = reference.getStore().pageSize - 1;

					if ( iCurrentRecordIndex == 0 )
					{
						var oThisBrowser = reference.up( '#TopLevelBrowser' );
						var oPrevButton = oThisBrowser.down( '#BrowserPrevButton' );
						var bPageChanged = GoPrevPage( oPrevButton );

						if ( bPageChanged )
						{
							oThisBrowser.down( '#BrowserLastSelectedIndex' ).setValue( iRecordsOnPageAsIndex );
							setTimeout( function ()
							{
								FocusOnSelectedRowIndex( oThisBrowser.down( '#gridpanelBrowserResults' ).getView() );
							}, 10 );
						}
					}
					break;
				case 40:

					var iCurrentRecordIndex = record.store.indexOf( record );
					var iRecordsOnPageAsIndex = reference.getStore().pageSize;

					var iRecordsOnPageAsIndex = reference.getStore().pageSize - 1;

					if ( iCurrentRecordIndex == iRecordsOnPageAsIndex )
					{
						var oThisBrowser = reference.up( '#TopLevelBrowser' );
						var oNextButton = oThisBrowser.down( '#BrowserNextButton' );
						var bPageChanged = GoNextPage( oNextButton );

						if ( bPageChanged )
						{
							oThisBrowser.down( '#BrowserLastSelectedIndex' ).setValue( 0 );
							setTimeout( function ()
							{
								FocusOnSelectedRowIndex( oThisBrowser.down( '#gridpanelBrowserResults' ).getView() );
							}, 10 );
						}
					}

					break;
				case 13:

					switch ( functionToPerform )
					{
						case "FillText":
							FillText( reference, record );
							break;
						case "FillTextForFilter":
							FillTextForFilter( reference, record );
							break;
						case "OpenFormWindow":
							OpenFormWindow( reference, record );
							break;
					}
					return true;
			}

			return true;
		};

		/*** End Launching Scripts ***/

		/*** Browser Layout and Button Scripts ***/

		this.SetEmptyText = function ( grid )
		{
			grid.getView().emptyText = '<div class="x-grid-empty">Search Returned no Results</div>';
		};

		this.CheckBrowserHeight = function ( reference )
		{
			var sContainer = Core.Ext.TopLevelContainer( reference );

			if ( reference.up( 'panel' ) )
			{
				if ( reference.up( 'panel' ).up( 'panel' ) && reference.up( 'panel' ).up( 'tabpanel' ) )
				{
					this.ResizeBrowser( reference.up( 'panel' ).up( 'tabpanel' ) );
				} else
				{
					this.ResizeBrowser( reference.up( 'panel' ) );
				}
			}
			/*if ( reference.up( 'panel' ).up( 'panel' ) )
			{
			if ( reference.up( 'panel' ).up( 'panel' ).itemId == "WindowBrowserTabPanel" )
			{
			iHeight = reference.up( 'window' ).getHeight() - ( reference.up( 'window' ).down( '#WorkOrderForm' ).getHeight() + reference.up( 'window' ).down( '#MainFilterResults' ).getHeight() );
			reference.setHeight( iHeight - 30 );
			}
			else if ( reference.up( 'panel' ).up( 'panel' ).id == "HomePageFilterResults" )
			{
			ResizeBrowser( reference.up( 'panel' ).up( 'panel' ) );
			}
			}
			else
			{
			} */
		};

		this.ResizeViewport = function ( viewport )
		{
			var oTabPanel = viewport.down( "#GroupDisplayPanel" );

			if ( oTabPanel != null )
			{
				this.ResizeBrowser(oTabPanel);
				// Core.Browser.ResizeBrowser( oTabPanel );
			}
		};

		this.ResizeBrowser = function ( panel )
		{
			switch ( panel.xtype )
			{
				case "tabpanel":

					if ( panel.getActiveTab() && panel.getActiveTab().down( '#gridpanelBrowserResults' ) )
					{
						var iPanelBodyHeight = panel.body.getHeight();

						var iPanelHeight = panel.getHeight();

						var iRegionHeight = panel.up().getHeight();

						var oContentPanel = panel.up().down( '#ContentPanel' );

						var iContentPanelHeight = 0;

						if ( oContentPanel != null )
						{
							iContentPanelHeight = oContentPanel.getHeight();
						}
						;

						/* sometimes the region is smaller than the reported panel size (window not maximized, console area, etc... and we need to adjust by the difference) */
						var iAdjustHeight = iRegionHeight - iContentPanelHeight - iPanelHeight;

						if ( iPanelHeight != iRegionHeight )
						{
							panel.setHeight( iRegionHeight - iContentPanelHeight );
						}

						/*var iFilterHeight = panel.getActiveTab().down( '#panelBrowserFilter' ).collapsed ? 31 : 190; //panel.getActiveTab().down( '#panelBrowserFilter' ).getHeight();

						set to 190 hard code for older IE browsers which do not detect the height*/

						var iFilterHeight = panel.getActiveTab().down( '#panelBrowserFilter' ).collapsed ? 31 : 190;

						panel.getActiveTab().down( '#TopLevelBrowser' ).setHeight( iPanelBodyHeight - 1 + iAdjustHeight );

						panel.getActiveTab().down( '#gridpanelBrowserResults' ).setHeight( iPanelBodyHeight - 34 - ( iFilterHeight - 31 ) + iAdjustHeight );

						this.CheckForLastColumnFlex( panel.getActiveTab() );
					}
					;
					break;
				case "panel":

					var iPanelBodyHeight = panel.body.getHeight();

					var iFilterHeight = panel.down( '#panelBrowserFilter' ).collapsed ? 31 : panel.down( '#panelBrowserFilter' ).getHeight();

					/*var iFilterHeight = panel.down( '#panelBrowserFilter' ).collapsed ? 31 : panel.down( '#panelBrowserFilter' ).getHeight(); //panel.getActiveTab().down( '#panelBrowserFilter' ).getHeight();

					set to 190 hard code for older IE browsers which do not detect the height*/

					var iFilterHeight = panel.down( '#panelBrowserFilter' ).collapsed ? 31 : 190;

					panel.down( '#TopLevelBrowser' ).setHeight( iPanelBodyHeight - 1 );

					panel.down( '#gridpanelBrowserResults' ).setHeight( iPanelBodyHeight - 70 - ( iFilterHeight - 31 ) );

					this.CheckForLastColumnFlex( panel );

					break;
				case "window":

					var iPanelBodyHeight = panel.body.getHeight();

					/*check if filter is collapsed*/
					var iFilterHeight = panel.down( '#panelBrowserFilter' ).collapsed ? 31 : panel.down( '#panelBrowserFilter' ).getHeight();

					if ( panel.down( '#containerTopBrowserButtons' ) )
					{
						iFilterHeight += panel.down( '#containerTopBrowserButtons' ).getHeight();
					}

					panel.down( '#TopLevelBrowser' ).setHeight( iPanelBodyHeight - 1 );

					panel.down( '#gridpanelBrowserResults' ).setHeight( iPanelBodyHeight - 39 - ( iFilterHeight - 31 ) );

					break;
			}
		};

		this.ErrorInTabs = function ( panel, tabs )
		{
			if ( tabs && tabs.length > 0 )
			{
				sFriendlyErrorMessage = "Error Loading Tab(s): " + tabs.replace( /•/g, ", " );
				sDetailedErrorMessage = "Errors occured while loading the attributes for the following Tabs: <p> " + tabs.replace( /•/g, "<br/>" ) + "</p>";

				Core.ErrorWindow( sDetailedErrorMessage, sFriendlyErrorMessage );
			}
			;
		};

		this.CheckForLastColumnFlex = function ( panel )
		{
			var iPanelWidth = panel.getWidth();

			var iColumnsWidth = 0;

			var oColumns = panel.down( '#gridpanelBrowserResults' ).columns;

			for ( i = 0 ; i < oColumns.length; i++ )
			{
				iColumnsWidth = iColumnsWidth + oColumns[i].width;
			}

			if ( iPanelWidth > iColumnsWidth )
			{
				oColumns[oColumns.length - 1].flex = 1;
			}
		};

		this.FocusOnSelectedRow = function ( gridview )
		{
			if ( window_focus )
			{
				var oThisBrowser = gridview.up( '#TopLevelBrowser' );

				var iRecord = oThisBrowser.down( '#BrowserLastSelectedIndex' ).getValue();

				var oThisBrowserResultsStore = oThisBrowser.down( '#gridpanelBrowserResults' ).getStore();

				var iRecordIndex = oThisBrowserResultsStore.find( "record", iRecord );

				if ( iRecordIndex < 0 )
				{
					iRecordIndex = 0;
				}

				gridview.getSelectionModel().select( iRecordIndex );
				//gridview.focusRow( 0 );
			}
		};

		this.FocusOnSelectedRowIndex = function ( gridview )
		{
			if ( window_focus )
			{
				var oThisBrowser = gridview.up( '#TopLevelBrowser' );

				var iRecordIndex = parseInt( oThisBrowser.down( '#BrowserLastSelectedIndex' ).getValue() );
				;

				gridview.getSelectionModel().select( iRecordIndex );
				//gridview.focusRow( 0 );
			}
		};

		this.ShowNestedBrowserButton = function ( reference, selectedIndex )
		{
			var oNestedBrowserButton = reference.up( '#TopLevelBrowser' ).down( '#btnNestedBrowser' );

			oNestedBrowserButton.show();
		};

		this.ShowSelectButton = function ( reference, selectedIndex, record )
		{
			var oSelectButton = reference.up( '#TopLevelBrowser' ).down( '#btnSelect' );

			oSelectButton.show();
		};

		/*** End Browser Layout and Button Scripts ***/

		/*** Monitor-based Script ***/

		this.HideStop = function ( reference )
		{
			reference.up( '#TopLevelBrowser' ).down( '#btnStopMonitor' ).hide();
			reference.up( '#TopLevelBrowser' ).down( '#btnStartMonitor' ).show();
		};

		this.HideStart = function ( reference )
		{
			reference.up( '#TopLevelBrowser' ).down( '#btnStopMonitor' ).show();
			reference.up( '#TopLevelBrowser' ).down( '#btnStartMonitor' ).hide();
		};

		this.StopTasks = function ( reference, browserGuid )
		{
			var oBrowserTaskManager = reference.up( '#TopLevelBrowser' ).bin[0]; /* seems id references to tasks are poor.  Task Manager is first Item in bin*/

			oBrowserTaskManager.stopAll();
		};

		this.StartTasks = function ( reference, browserGuid )
		{
			var oBrowserTaskManager = reference.up( '#TopLevelBrowser' ).bin[0]; /* seems id references to tasks are poor.  Task Manager is first Item in bin*/

			oBrowserTaskManager.startAll();
		};

		/*** End Monitor-based Script ***/

		/*** Data retrieval Scripts ***/

		this.RefreshBrowser = function ( browser )
		{
			if ( $( browser.getEl() )[0].is( ':visible' ) )
			{
				var iCurrentPage = browser.down( '#BrowserPaging' ).store.currentPage;

				browser.down( '#BrowserPageToLoad' ).setValue( iCurrentPage );

				browser.down( '#btnSearch' ).fireEvent( 'click' );
			}
		};

		this.RefreshBrowserById = function ( counter, browserGuid )
		{
			var oThisBrowser = FindBrowserByGuid( browserGuid );

			RefreshBrowser( oThisBrowser );
		};

		this.ResetLastSelectedRecord = function ( grid )
		{
			var oThisBrowser = grid.up( '#TopLevelBrowser' );

			oThisBrowser.down( '#BrowserLastSelectedIndex' ).setValue( 0 );
		};

		this.SetLastSelectedRecord = function ( grid )
		{
			var iRowIndex = FindSelectedRowIndex( grid );

			var oThisBrowser = grid.up( '#TopLevelBrowser' );

			oThisBrowser.down( '#BrowserLastSelectedIndex' ).setValue( iRowIndex );
		};

		this.UpdateBrowserResults = function ( grid, result )
		{
			if ( result )
			{
				if ( result.IsError )
				{
					Core.Ext.HideMask( grid );

					Core.ErrorWindow( result.ErrorMessage.DetailedErrorMessage, result.ErrorMessage.FriendlyErrorMessage );
				} else
				{
					var oThisBrowser = grid.up( '#TopLevelBrowser' );

					oThisBrowser.down( '#BrowserFullDataCount' ).setValue( result.RecordCount );
					oThisBrowser.down( '#BrowserPageSize' ).setValue( result.PageSize );
					oThisBrowser.down( '#BrowserDynamicLaunchJson' ).setValue( result.DynamicLaunchJson );
					grid.getStore().sorters.clear();

					//grid.show();
					grid.getStore().pageSize = parseInt( grid.down( '#gridpanelComboBoxPaging' ).getValue(), 10 );
					grid.getStore().loadData( result.BrowserResults );

					var iPageToLoad = parseInt( oThisBrowser.down( '#BrowserPageToLoad' ).getValue() );
					if ( iPageToLoad == -1 )
					{
						/* find the local page count, and go to the last one - we came back from a page and can't use it's page count (might not be as large) */
						var oPaging = grid.down( '#BrowserPaging' ),
							iPageToLoad = oPaging.getPageData().pageCount;
					}

					grid.getStore().loadPage( iPageToLoad );
					Core.Ext.HideMask( grid );
					oThisBrowser.down( '#tabSqlCriteria' ).update( result.AsSql );
					this.PagingDisplayControlsToggle( grid );

					setTimeout( function ()
					{
						FocusOnSelectedRowIndex( grid.getView() );
					}, 10 );
				}
			}
		};

		this.UpdateBrowserFilters = function ( reference, result )
		{
			if ( result && result.data )
			{
				if ( !result.data.IsError )
				{
					var oFilterGrid = reference.down( '#tabFilterCriteria' );
					var oSortGrid = reference.down( '#tabSortCriteria' );

					oFilterGrid.getStore().loadData( result.data.BrowserFilterSet );
					oSortGrid.getStore().loadData( result.data.BrowserSortSet );
				} else
				{
					Core.ErrorWindow( result.data.ErrorMessage.DetailedErrorMessage, result.data.ErrorMessage.FriendlyErrorMessage );
				}
			}
		};

		this.SetBrowserLocalPageCookie = function ( combo )
		{
			var oTopLevelBrowser = combo.up( '#TopLevelBrowser' );

			var sContainerName = oTopLevelBrowser.down( "#ContainerName" ).getValue();

			if ( oTopLevelBrowser.up( '#GroupDisplayPanel' ) )
			{
				Ext.net.DirectMethod.request( {
					url: sRoot + "Cookie/SetHomePageConfiguration",
					cleanRequest: true,
					params: {
						key: 'HomeBrowser' + sContainerName
	, keyStringValue: combo.getValue()
					}
				} );
			}
			;
		};

		/*** End Data Retrieval Scripts ***/

		/*** Object Finding Scripts ***/

		this.FindBrowserByGuid = function ( browserGuid )
		{
			var oAllBrowsers = Ext.ComponentQuery.query( "#TopLevelBrowser" );

			var oThisBrowser;

			for ( i = 0; i < oAllBrowsers.length; i++ )
			{
				if ( oAllBrowsers[i].down( "#BrowserGuid" ).getValue() == browserGuid )
				{
					oThisBrowser = oAllBrowsers[i];
				}
			}

			return oThisBrowser;
		};

		this.FindSelectedRow = function ( reference )
		{
			var oBrowserGrid = reference.up( '#TopLevelBrowser' ).down( '#gridpanelBrowserResults' );

			var oRow;

			if ( oBrowserGrid.getSelectionModel().hasSelection() )
			{
				oRow = oBrowserGrid.getSelectionModel().getSelection()[0];
			}

			return oRow;
		};

		this.FindSelectedRowIndex = function ( reference )
		{
			var oBrowserGrid = reference.up( '#TopLevelBrowser' ).down( '#gridpanelBrowserResults' );

			var oRowIndex = 0;

			if ( oBrowserGrid.getSelectionModel().hasSelection() )
			{
				var oRow = oBrowserGrid.getSelectionModel().getSelection()[0];
				oRowIndex = oBrowserGrid.getStore().indexOf( oRow );
			}

			return oRowIndex;
		};

		this.FindSelectedItem = function ( reference, dataColumn )
		{
			var oRow = FindSelectedRow( reference );

			var oSelectedItem = oRow ? oRow.get( dataColumn ) : null;

			return oSelectedItem;
		};

		/*** End Object Finding Scripts ***/

		this.GetContextMenuCheck = function ( contextMenu )
		{
			var deferreds = [];

			var oMenuItems = contextMenu.items.items;

			var i = 0;

			for ( i = 0 ; i < oMenuItems.length ; i++ )
			{
				//var count = i;
				if ( oMenuItems[i].preprocessor.Trim() != "" )
				{
					var sSqlString = oMenuItems[i].preprocessor;

					var sConstructSql = sSqlString.replace( /\'/g, "" );

					var saConstructSql = sConstructSql.split( " " );

					for ( var j = 0; j < saConstructSql.length ; j++ )
					{
						if ( saConstructSql[j].indexOf( "@" ) == 0 )
						{
							var sReplaceVal = saConstructSql[j];

							switch ( sReplaceVal )
							{
								case "@ps_user_id":

									sSqlString = sSqlString.replace( new RegExp( sReplaceVal, 'g' ), "'" + App.UserId.getValue() + "'" );

									break;
								case "@ps_config":

									sSqlString = sSqlString.replace( new RegExp( sReplaceVal, 'g' ), "'" + App.Configuration.getValue() + "'" );

									break;
								case "@ps_client_app":

									sSqlString = sSqlString.replace( new RegExp( sReplaceVal, 'g' ), "'CvClientApplication'" );

									break;
								default:

									var sLookupColumn = sReplaceVal.replace( "@pb_", "" );

									var oLookupValue = contextMenu.dataRecord.get( sLookupColumn );

									sSqlString = sSqlString.replace( new RegExp( sReplaceVal, 'g' ), oLookupValue.toString() );

									break;
							}
						}
					}

					deferreds.push(
						$.post( sRoot + "Clearview/Preprocessor", {
							s: sSqlString,
							itemIndex: i,
							token: App.Token.getValue()
						}
							)
							.success( function ( result )
							{
								var oReturnVals = result.result;

								oReturnVals.bReturnVal ? oMenuItems[oReturnVals.itemIndex].show() : oMenuItems[oReturnVals.itemIndex].hide();
							}
								)
						);
				} else
				{
					oMenuItems[i].show();
				}
			}

			return deferreds;
		};

		this.BrowserContextMenu = function ( grid, index, e, browserGuid )
		{
			e.preventDefault();

			var oContextMenu = Ext.ComponentQuery.query( '#BrowserContextMenu' + browserGuid )[0];

			oContextMenu.dataRecord = grid.store.getAt( index );
			oContextMenu.grid = grid;

			var deferreds = GetContextMenuCheck( oContextMenu );

			$.when.apply( null, deferreds ).done( function ()
			{
				var oPostion = e.getXY();

				if ( oPostion[0] == 0 && oPostion[1] == 0 )
				{
					oPostion[0] = $( grid.focusedRow ).offset().left;
					oPostion[1] = $( grid.focusedRow ).offset().top;
				}
				oContextMenu.showAt( oPostion );
			} );
		};

		this.ContextMenuAction = function ( command, commandArguments, commandType, menuId, refresh, browserId, menuItem )
		{
			switch ( commandType )
			{
				case "CBR":

					var oBrowser = menuItem.up().grid.up( "#TopLevelBrowser" );

					this.SetLastSelectedRecord( oBrowser.down( '#gridpanelBrowserResults' ) );

					Core.Ext.ShowMask( oBrowser, "Running CBR..." );

					Ext.net.DirectMethod.request( {
						url: sRoot + "Clearview/ContextMenuCBR",
						cleanRequest: true,
						params: {
							browserId: browserId
	, menuId: menuId
	, record: menuItem.parentMenu.dataRecord.get( "record" )
	, refresh: refresh
	, token: App.Token.getValue()
						},
						success: function ( result )
						{
							if ( result.IsError )
							{
								Core.ErrorWindow( result.ErrorMessage.DetailedErrorMessage, result.ErrorMessage.FriendlyErrorMessage );
							}
							;

							Core.Ext.HideMask( oBrowser );

							if ( refresh )
							{
								Core.Browser.RefreshBrowser( oBrowser );
							}
						},
						failure: function ( result )
						{
							Core.ErrorWindow( "Unknown CBR Error", "Unknown CBR Error" );

							Core.Ext.HideMask( oBrowser );
						}
					} );

					break;
				case "FRM":

					if ( command.Trim() != "" )
					{
						var oCommandArguments = JSON.parse( commandArguments );

						var sLaunchParameters = "?SESSIONTOKEN=" + App.Token.getValue() + "&USESOAP=" + App.UseSoap.getValue();

						for ( var i = 0; i < oCommandArguments.length; i++ )
						{
							sLaunchParameters += "&" + oCommandArguments[i].QueryKey + "=";

							if ( oCommandArguments[i].IsLookup )
							{
								sLaunchParameters += menuItem.parentMenu.dataRecord.get( oCommandArguments[i].DataColumn );
							} else
							{
								sLaunchParameters += oCommandArguments[i].DataColumn;
							}
						}

						var sLaunchForm = BuildLaunchForm( command );

						var oContainer = App.ContainerStore.findRecord( 'Name', command );

						var iHeight = oContainer ? oContainer.get( 'Height' ) : 800;

						var iWidth = oContainer ? oContainer.get( 'Width' ) : 800;

						window.open( sLaunchForm + sLaunchParameters, '_blank', 'width=' + iWidth + ',height=' + iHeight + ',resizable=yes,location=no,menubar=no' );
					} else
					{
						OpenFormWindow( null, menuItem.parentMenu.dataRecord, commandArguments );
					}
					break;
				case "URL":

					var oCommandArguments = JSON.parse( commandArguments );

					var sLaunchParameters = GetContextLaunchParameters( oCommandArguments, menuItem.parentMenu.dataRecord );

					var oContainer = App.ContainerStore.findRecord( 'Name', command );

					var iHeight = oContainer ? oContainer.get( 'Height' ) : 800;
					var iWidth = oContainer ? oContainer.get( 'Width' ) : 800;

					if ( command.indexOf( "http" ) > -1 )
					{
						window.open( command + sLaunchParameters, '_blank', 'width=' + iWidth + ',height=' + iHeight + ',resizable=yes' );
					} else if ( command.indexOf( "/" ) > -1 )
					{
						var sLaunchForm = BuildLaunchForm( command );

						window.open( sLaunchForm + sLaunchParameters, '_blank', 'width=' + iWidth + ',height=' + iHeight + ',resizable=yes' );
					} else
					{
						window.open( menuItem.parentMenu.dataRecord.get( oCommandArguments[0].DataColumn ), '_blank', 'width=' + iWidth + ',height=' + iHeight + ',resizable=yes' );
					}

					break;
			}
		};

		this.FillLastConfigurationJson = function ( topLevelBrowser, isAutoFetch )
		{
			if ( parseBool( isAutoFetch ) )
			{
				this.StoresToJson( topLevelBrowser.down( 'hidden' ) );

				this.CopyStoresToLastJson( topLevelBrowser.down( 'hidden' ) );
			}
		};

		this.CheckForExportError = function ( result )
		{
			if ( result.IsError )
			{
				Core.ErrorWindow( result.ErrorMessage.DetailedErrorMessage, result.ErrorMessage.FriendlyErrorMessage );
			}
		};

		this.GetVisibleColumnNames = function ( reference )
		{
			var oGrid = reference.up( '#TopLevelBrowser' ).down( '#gridpanelBrowserResults' );

			var sColumns = "";

			oGrid.columns.forEach( function ( item )
			{
				if ( item.isVisible() )
				{
					sColumns = sColumns + item.text.replace( "&#160", " " ) + ",";
				}
			} );

			sColumns
			= sColumns.length > 0
			  ? sColumns.substring( 0, sColumns.length - 1 )
			  : "";

			return sColumns;
		};
	} ).apply( this.Browser || {} );
} ).apply( Core || {} );