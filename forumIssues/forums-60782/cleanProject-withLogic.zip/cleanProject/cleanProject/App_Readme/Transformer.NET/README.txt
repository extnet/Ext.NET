﻿Project      : Transformer.NET
Version      : 2.1.1
Last Updated : 2012-12-16

--------------------------------------------------------------------------
   DESCRIPTION
--------------------------------------------------------------------------

A .NET template parsing and transformation library. 